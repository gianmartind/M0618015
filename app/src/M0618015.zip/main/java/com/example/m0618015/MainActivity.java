package com.example.m0618015;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.example.m0618015.databinding.ActivityMainBinding;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    ActivityMainBinding bind;
    Bitmap mBitmap;
    Canvas mCanvas;
    Paint paint;
    Paint whitePaint;
    UIThreadedWrapper handler;
    LinkedList<CustomThread> threadList;
    boolean canvasInitiated;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.bind = ActivityMainBinding.inflate(getLayoutInflater());
        View view = this.bind.getRoot();
        setContentView(view);

        this.paint = new Paint();
        this.paint.setStyle(Paint.Style.FILL);
        this.paint.setColor(ResourcesCompat.getColor(getResources(), R.color.black, null));

        this.whitePaint = new Paint();
        this.whitePaint.setStyle(Paint.Style.FILL);
        this.whitePaint.setColor(ResourcesCompat.getColor(getResources(), R.color.white, null));


        this.bind.btnStart.setOnClickListener(this);
        this.bind.btnStop.setOnClickListener(this);

        this.canvasInitiated = false;
        this.threadList = new LinkedList<>();
        this.handler = new UIThreadedWrapper(this);
    }

    @Override
    public void onClick(View v) {

        if(v == this.bind.btnStart){
            
            this.mBitmap = Bitmap.createBitmap(this.bind.ivCanvas.getWidth(), this.bind.ivCanvas.getHeight(), Bitmap.Config.ARGB_8888);
            this.bind.ivCanvas.setImageBitmap(this.mBitmap);
            this.mCanvas = new Canvas(this.mBitmap);
            this.canvasInitiated = true;

            Random random = new Random();
            float randX = random.nextInt(20) - 10;
            float randY = random.nextInt(20) - 10;
            Coordinate coordinateMax = new Coordinate(this.bind.ivCanvas.getWidth(), this.bind.ivCanvas.getHeight());
            Coordinate coordinateStart = new Coordinate(this.bind.ivCanvas.getWidth()/2, this.bind.ivCanvas.getHeight()/2);
            Coordinate coordinateDir = new Coordinate(randX, randY);
            this.threadList.addFirst(new CustomThread(this.handler, coordinateDir, coordinateMax, coordinateStart));
            this.threadList.getFirst().start();
        } else if(v == this.bind.btnStop){
            while(!this.threadList.isEmpty()){
                this.threadList.removeFirst().stopThread();
            }
            //this.mCanvas.drawColor(ResourcesCompat.getColor(getResources(), R.color.white, null));
        }
    }

    public void setCircle(Coordinate coordinate){
        //this.mCanvas.drawColor(ResourcesCompat.getColor(getResources(), R.color.white, null));
        this.mCanvas.drawCircle(coordinate.getX(), coordinate.getY(), 100, this.paint);
        this.bind.ivCanvas.invalidate();
    }

    public void setWhiteCirlce(Coordinate coordinate){
        this.mCanvas.drawCircle(coordinate.getX(), coordinate.getY(), 100, this.whitePaint);
    }
}