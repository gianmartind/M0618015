package com.example.m0618015;

import android.util.Log;

import java.util.Random;

public class CustomThread extends Thread {
    protected UIThreadedWrapper uiThreadedWrapper;
    protected Coordinate coordinateDir;
    protected Coordinate coordinateMax;
    protected Coordinate coordinateStart;
    protected boolean stopped = false;

    public CustomThread(UIThreadedWrapper uiThreadedWrapper, Coordinate coordinateDir, Coordinate coordinateMax, Coordinate coordinateMin){
        this.uiThreadedWrapper = uiThreadedWrapper;
        this.coordinateDir = coordinateDir;
        this.coordinateMax = coordinateMax;
        this.coordinateStart = coordinateMin;
    }

    public void stopThread(){
        Log.d("TAG", "stopThread: ");
        this.stopped = true;
    }

    public void run() {
        this.stopped = false;
        float x = this.coordinateStart.getX();
        float y = this.coordinateStart.getY();
        while(checkValid(x, y) && !this.stopped){
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
                return;
            }

            uiThreadedWrapper.clearCircle(new Coordinate(x, y));
            x += this.coordinateDir.getX();
            y += this.coordinateDir.getY();
            uiThreadedWrapper.drawCircle(new Coordinate(x, y));
        }
    }

    public boolean checkValid(float x, float y){
        Random random = new Random();
        if(x < 0 - 105 || y < 0 - 105){
            //this.coordinateDir.setX(random.nextInt(20) - 10);
            //this.coordinateDir.setY(random.nextInt(20) - 10);
            return false;
        }

        if(x > this.coordinateMax.getX() + 105 || y > this.coordinateMax.getY() + 105){
            //this.coordinateDir.setX(random.nextInt(20) - 10);
            //this.coordinateDir.setY(random.nextInt(20) - 10);
            return false;
        }

        return true;
    }
}
